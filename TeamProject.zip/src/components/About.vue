<template>
	<main id="about-page">
		<h1>About us</h1>
		<ul>
			


		</ul>
	</main>
</template>