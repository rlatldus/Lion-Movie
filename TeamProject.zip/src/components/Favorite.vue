<template>
	<main id="Favorite-page">
		<h1>Favorite</h1>
		<p>This is the favorite page</p>
	</main>
</template>