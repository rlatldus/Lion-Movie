<template>
	<main id="Register-page">
		<h1>Register</h1>
		<p>This is the register page</p>
	</main>
</template>