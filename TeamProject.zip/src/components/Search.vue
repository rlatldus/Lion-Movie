<template>
	<main id="Search-page">
		<h1>Search</h1>
		<p>This is the search page</p>
	</main>
</template>