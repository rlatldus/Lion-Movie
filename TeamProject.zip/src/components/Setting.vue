<template>
	<main id="Setting-page">
		<div>
			<h1><span class="material-icons setting">settings</span>Setting</h1>
		</div>
		<div class="Setting_icons">
			<ul class="set">
				<li></li>
				<li></li>
				<li></li>
			</ul>
		</div>

	</main>
</template>


<style scoped>



h1{
	display: flex;

}

main{
	background-color: #1d4d77;
}


.setting{
	margin-right: 15px;
	font-size: 120%;
	
}

</style>