<template>
	<main id="Setting-page">
		<div>
			<h1><span class="material-icons setting">settings</span>Setting</h1>
		</div>
		<div class="setting_icons">
			<ul class="set">
				<li>dd</li>
				<li>dd</li>
			</ul>
		</div>

	</main>
</template>


<style scoped>

li {
	list-style: none;
	height: auto;

}

li>span{
	font-size: 150px;
}

h1{
	display: flex;

}

main{
	background-color: #1d4d77;
}


.setting{
	margin-right: 15px;
	font-size: 120%;
	
}
.setting_icons{
	margin-top: 30px;
	background-color: rgb(32, 196, 196);
}


</style>